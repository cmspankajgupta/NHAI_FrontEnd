import React from 'react'

const ServicePage = () => {
    throw new Error("we are getting error!");
  return (
    <div>
      ServicePage
    </div>
  )
}

export default ServicePage
