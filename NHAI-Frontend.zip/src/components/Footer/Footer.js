import React from 'react'

const Footer = () => {
  return (
    <div style={{background:'red'}}>
      Footer
    </div>
  )
}

export default Footer
